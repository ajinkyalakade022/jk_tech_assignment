# Book Management System

This project is an intelligent book management system built with FastAPI, SQLAlchemy, and machine learning.

## Features
- CRUD operations for books
- Review management
- Book summarization using Llama3 model
- Book recommendations using a machine learning model

## Setup
1. **Create a virtual environment**:
    ```sh
    python -m venv venv
    source venv/bin/activate  # On Windows use `venv\Scripts\activate`
    ```

2. **Install dependencies**:
    ```sh
    pip install -r requirements.txt
    ```

3. **Run the database migrations**:
    ```sh
    python scripts/create_tables.sql
    ```

4. **Run the application**:
    ```sh
    uvicorn app.main:app --reload
    ```

5. **Run the tests**:
    ```sh
    pytest
    ```

## Deployment
- **Docker**: Build and run the Docker container:
    ```sh
    docker build -t book-management-system .
    docker run -p 80:80 book-management-system
    ```

- **AWS**: Deploy using EC2, RDS, and S3.

## Usage
- **Swagger UI**: Access API documentation at `http://localhost:8000/docs`.
- **ReDoc**: Access alternative API documentation at `http://localhost:8000/redoc`.

