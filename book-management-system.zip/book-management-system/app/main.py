from fastapi import FastAPI, HTTPException, Depends
from pydantic import BaseModel
from typing import List
from sqlalchemy.ext.asyncio import AsyncSession
from .database import SessionLocal, engine
from . import models, schemas, crud, llama3_model, ml_model

models.Base.metadata.create_all(bind=engine)

app = FastAPI()

# Dependency to get DB session
async def get_db():
    async with SessionLocal() as session:
        yield session

# API endpoints
@app.post("/books/", response_model=schemas.Book)
async def create_book(book: schemas.BookCreate, db: AsyncSession = Depends(get_db)):
    return await crud.create_book(db=db, book=book)

@app.get("/books/", response_model=List[schemas.Book])
async def read_books(db: AsyncSession = Depends(get_db)):
    return await crud.get_books(db)

@app.get("/books/{book_id}", response_model=schemas.Book)
async def read_book(book_id: int, db: AsyncSession = Depends(get_db)):
    book = await crud.get_book(db, book_id)
    if book is None:
        raise HTTPException(status_code=404, detail="Book not found")
    return book

@app.put("/books/{book_id}", response_model=schemas.Book)
async def update_book(book_id: int, book: schemas.BookCreate, db: AsyncSession = Depends(get_db)):
    return await crud.update_book(db, book_id, book)

@app.delete("/books/{book_id}")
async def delete_book(book_id: int, db: AsyncSession = Depends(get_db)):
    await crud.delete_book(db, book_id)
    return {"message": "Book deleted successfully"}

@app.post("/books/{book_id}/reviews/", response_model=schemas.Review)
async def create_review(book_id: int, review: schemas.ReviewCreate, db: AsyncSession = Depends(get_db)):
    return await crud.create_review(db=db, review=review)

@app.get("/books/{book_id}/reviews/", response_model=List[schemas.Review])
async def read_reviews(book_id: int, db: AsyncSession = Depends(get_db)):
    return await crud.get_reviews(db, book_id)

@app.get("/books/{book_id}/summary")
async def get_book_summary(book_id: int, db: AsyncSession = Depends(get_db)):
    return await crud.get_book_summary(db, book_id)

@app.get("/recommendations")
async def get_recommendations(genre: str, rating: float):
    return ml_model.get_recommendations(genre, rating)

@app.post("/generate-summary")
async def generate_book_summary(content: str):
    return llama3_model.generate_summary(content)
