from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import selectinload
from . import models, schemas

async def get_books(db: AsyncSession):
    result = await db.execute(select(models.Book))
    return result.scalars().all()

async def get_book(db: AsyncSession, book_id: int):
    result = await db.execute(select(models.Book).filter(models.Book.id == book_id))
    return result.scalar()

async def create_book(db: AsyncSession, book: schemas.BookCreate):
    db_book = models.Book(**book.dict())
    db.add(db_book)
    await db.commit()
    await db.refresh(db_book)
    return db_book

async def update_book(db: AsyncSession, book_id: int, book: schemas.BookCreate):
    result = await db.execute(select(models.Book).filter(models.Book.id == book_id))
    db_book = result.scalar()
    if db_book is None:
        return None
    for key, value in book.dict().items():
        setattr(db_book, key, value)
    db.add(db_book)
    await db.commit()
    await db.refresh(db_book)
    return db_book

async def delete_book(db: AsyncSession, book_id: int):
    result = await db.execute(select(models.Book).filter(models.Book.id == book_id))
    db_book = result.scalar()
    if db_book is None:
        return None
    await db.delete(db_book)
    await db.commit()

async def get_reviews(db: AsyncSession, book_id: int):
    result = await db.execute(select(models.Review).filter(models.Review.book_id == book_id))
    return result.scalars().all()

async def create_review(db: AsyncSession, review: schemas.ReviewCreate):
    db_review = models.Review(**review.dict())
    db.add(db_review)
    await db.commit()
    await db.refresh(db_review)
    return db_review

async def get_book_summary(db: AsyncSession, book_id: int):
    result = await db.execute(select(models.Book).filter(models.Book.id == book_id))
    book = result.scalar()
    if book is None:
        return None
    return {"summary": book.summary}
